package Snake_Game;

public class Node 
{
  int r;
  int c;
  char val;
  Node(int r,int c,char val)
  {
	  this.r=r;
	  this.c=c;
	  this.val=val;
  }
}
